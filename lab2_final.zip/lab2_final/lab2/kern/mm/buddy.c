#include <pmm.h>
#include <list.h>
#include <string.h>
#include <default_pmm.h>
#include <buddy.h>
//来自参考资料的一些宏定义
#define LEFT_LEAF(index) ((index) * 2 + 1)
#define RIGHT_LEAF(index) ((index) * 2 + 2)
#define PARENT(index) ( ((index) + 1) / 2 - 1)

#define IS_POWER_OF_2(x) (!((x)&((x)-1)))
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define UINT32_SHR_OR(a,n)      ((a)|((a)>>(n)))//右移n位  

#define UINT32_MASK(a)          (UINT32_SHR_OR(UINT32_SHR_OR(UINT32_SHR_OR(UINT32_SHR_OR(UINT32_SHR_OR(a,1),2),4),8),16))    
//大于a的一个最小的2^k
#define UINT32_REMAINDER(a)     ((a)&(UINT32_MASK(a)>>1))
#define UINT32_ROUND_DOWN(a)    (UINT32_REMAINDER(a)?((a)-UINT32_REMAINDER(a)):(a))//小于a的最大的2^k

static unsigned fixsize(unsigned size) {
    size |= size >> 1;
    size |= size >> 2;
    size |= size >> 4;
    size |= size >> 8;
    size |= size >> 16;
    return size + 1;
}

struct buddy2 {
    unsigned size;//表明管理内存
    unsigned longest;
};
struct buddy2 root[80000];//存放二叉树的数组，用于内存分配

free_area_t free_area;

#define free_list (free_area.free_list)
#define nr_free (free_area.nr_free)

struct allocRecord//记录分配块的信息
{
    struct Page* base;
    int offset;
    size_t nr;//块大小
};

struct allocRecord rec[80000];//存放偏移量的数组
int nr_block;//已分配的块数

static void buddy_init()
{
    list_init(&free_list);
    nr_free = 0;
}

//初始化二叉树上的节点
void buddy2_new(int size) {
    unsigned node_size;
    int i;
    nr_block = 0;
    //如果传入的希望分配的size不是2的n次方，返回
    if (size < 1 || !IS_POWER_OF_2(size))
        return;

    root[0].size = size;
    node_size = size * 2;

    for (i = 0; i < 2 * size - 1; ++i) {
        if (IS_POWER_OF_2(i + 1))//注意1是2的0次幂！！！！！所以i=1可以进入if
            node_size /= 2;
        root[i].longest = node_size;
    }
    return;
}

//初始化内存映射关系。初始化物理上page的链表；从base开始，初始化有n个page接下来可以被分配
static void buddy_init_memmap(struct Page* base, size_t n)
{
    assert(n > 0);
    struct Page* p = base;
    for (; p != base + n; p++)
    {
        assert(PageReserved(p));//检查是否为保留页，这一页为内核保留
        p->flags = 0;
        p->property = 1;//拥有一个可以free的block
        set_page_ref(p, 0);//将page p的ref位置0，表示有0个使用该page的
        SetPageProperty(p);
        list_add_before(&free_list, &(p->page_link));
    }
    nr_free += n;
    int allocpages = UINT32_ROUND_DOWN(n);//n向上取整
    buddy2_new(allocpages);//对buddy管理系统初始化

}


//内存分配，只是在buddy中分配，相当于更新管理系统，还没有分配的物理pages
int buddy2_alloc(struct buddy2* self, int size) {
    unsigned index = 0;//节点的标号
    unsigned node_size;
    unsigned offset = 0;

    if (self == NULL)//无法分配
        return -1;

    if (size <= 0)//分配不合理
        size = 1;
    else if (!IS_POWER_OF_2(size))//不为2的幂时，取比size更大的2的n次幂
        size = fixsize(size);

    if (self[index].longest < size)//可分配内存不足
        return -1;

    //通过循环找到要分配的那个index。从上往下找，找到要分配的index
    for (node_size = self->size; node_size != size; node_size /= 2) {
        if (self[LEFT_LEAF(index)].longest >= size)
        {
            if (self[RIGHT_LEAF(index)].longest >= size)
            {
                //找到两个相符合的节点中内存较小的结点
                index = self[LEFT_LEAF(index)].longest <= self[RIGHT_LEAF(index)].longest ? LEFT_LEAF(index) : RIGHT_LEAF(index);
            }
            else
            {
                index = LEFT_LEAF(index);
            }
        }
        else
            index = RIGHT_LEAF(index);
    }

    //此时的index为要分配的结点
    self[index].longest = 0;//标记节点为已使用
    offset = (index + 1) * node_size - self->size;//通过index算出offset

    //开始时的index为分配完的结点
    //通过while向上刷新，修改所有路径上结点的数值
    while (index) {
        index = PARENT(index);
        self[index].longest =
            MAX(self[LEFT_LEAF(index)].longest, self[RIGHT_LEAF(index)].longest);
    }
    return offset;
}

//真正实现allocpages个page可以用，把可以用的pages连在一起
static struct Page* buddy_alloc_pages(size_t n) {
    assert(n > 0);
    if (n > nr_free)
        return NULL;

    struct Page* page = NULL;
    struct Page* p;
    list_entry_t* le = &free_list;
    list_entry_t* len;

    //对数组存的二叉树的管理部分进行操作，修改longest并回溯，并记录offset
    //有了offset才能在freelist里找到开始分配的起点，才能分配出allocpages个pages用
    rec[nr_block].offset = buddy2_alloc(root, n);

    int i;
    //le刚开始是freelist的头，通过循环移动到偏移量处，即将要开始分配的块的起点
    for (i = 0; i < rec[nr_block].offset + 1; i++)
        le = list_next(le);

    // 从list_entry类型的le 转成 page
    page = le2page(le, page_link);

    //确定allocpages，根据需求n得到块大小
    int allocpages;
    if (!IS_POWER_OF_2(n))
        allocpages = fixsize(n);
    else
    {
        allocpages = n;
    }
  
  
    rec[nr_block].base = page;//记录分配了的块的首页
    rec[nr_block].nr = allocpages;//记录分配的块大小
    nr_block++;

    //修改每个page的状态
    //循环前le已经在偏移量处，只需要把allocpages这么多的list entry对应的page状态进行修改即可
    for (i = 0; i < allocpages; i++)
    {
        p = le2page(le, page_link);
        ClearPageProperty(p);//将flag里的PG_property置0，表示已经被分配
        le= list_next(le);
    }
    nr_free -= allocpages;//减去已被分配的页数
    page->property = n;//从page开始就有了n个page可以用了，page是一个起点
    return page;
}

void buddy_free_pages(struct Page* base, size_t n) {
    unsigned node_size, index = 0;
    unsigned left_longest, right_longest;
    struct buddy2* self = root;

    list_entry_t* le = list_next(&free_list);
    int i = 0;
    for (i = 0; i < nr_block; i++)//找到块
    {
        if (rec[i].base == base)
            break;
    }
    int offset = rec[i].offset;
    //暂存i，要回收的块在rec中索引是i
    int pos = i;
    i = 0;
    //初始化的le指向freelist头，通过循环使le到偏移量处
    while (i < offset)
    {
        le = list_next(le);
        i++;
    }
    //要释放allocpages个页
    int allocpages;
    if (!IS_POWER_OF_2(n))
        allocpages = fixsize(n);
    else
    {
        allocpages = n;
    }

    assert(self && offset >= 0 && offset < self->size);//是否合法
    node_size = 1;
    index = offset + self->size - 1;//index为管理系统里的数组的索引
    nr_free += allocpages;//更新空闲页的数量
    struct Page* p;
    self[index].longest = allocpages;//buddy里对应的这个结点释放，释放了allocpages个，所以longest = allocpages

    //修改每个page的状态
    //此时的le在偏移量处，在物理上回收已分配的页
    for (i = 0; i < allocpages; i++)
    {
        p = le2page(le, page_link);
        p->flags = 0;
        p->property = 1;
        SetPageProperty(p);//将flag里的PG_property置1，表示是free的
        le = list_next(le);
    }

    //更新恢复管理系统中的各个值
    while (index) {//向上合并，修改先祖节点的记录值
        index = PARENT(index);
        node_size *= 2;

        left_longest = self[LEFT_LEAF(index)].longest;
        right_longest = self[RIGHT_LEAF(index)].longest;

        //能合并的合并
        if (left_longest + right_longest == node_size)
            self[index].longest = node_size;
        else
            self[index].longest = MAX(left_longest, right_longest);
    }
    for (i = pos; i < nr_block - 1; i++)//清除此次的分配记录，后面的往前提
    {
        rec[i] = rec[i + 1];
    }
    nr_block--;//更新分配块数的值
}

//返回现在可以free的page数量
static size_t buddy_nr_free_pages(void) {
    return nr_free;
}

//以下是一个测试函数
static void buddy_check(void) {
    struct Page* p0, * A, * B, * C, * D;
    p0 = A = B = C = D = NULL;

    assert((p0 = alloc_page()) != NULL);
    assert((A = alloc_page()) != NULL);
    assert((B = alloc_page()) != NULL);

    assert(p0 != A && p0 != B && A != B);
    assert(page_ref(p0) == 0 && page_ref(A) == 0 && page_ref(B) == 0);//确保几个页的ref都是0
    free_page(p0);
    free_page(A);
    free_page(B);

    A = alloc_pages(500);
    B = alloc_pages(500);
    cprintf("A %p\n", A);
    cprintf("B %p\n", B);
    free_pages(A, 250);
    free_pages(B, 500);
    free_pages(A + 250, 250);

    p0 = alloc_pages(1024);
    cprintf("p0 %p\n", p0);
    assert(p0 == A);
    //以下是根据链接中的样例测试编写的
    A = alloc_pages(70);
    B = alloc_pages(35);
    assert(A + 128 == B);//检查是否相邻
    cprintf("A %p\n", A);
    cprintf("B %p\n", B);
    C = alloc_pages(80);
    assert(A + 256 == C);//检查C有没有和A重叠
    cprintf("C %p\n", C);
    free_pages(A, 70);//释放A
    cprintf("B %p\n", B);
    D = alloc_pages(60);
    cprintf("D %p\n", D);
    assert(B + 64 == D);//检查B，D是否相邻
    free_pages(B, 35);
    cprintf("D %p\n", D);
    free_pages(D, 60);
    cprintf("C %p\n", C);
    free_pages(C, 80);
    free_pages(p0, 1000);//全部释放
}

const struct pmm_manager buddy_pmm_manager = {
    .name = "buddy_pmm_manager",
    .init = buddy_init,
    .init_memmap = buddy_init_memmap,
    .alloc_pages = buddy_alloc_pages,
    .free_pages = buddy_free_pages,
    .nr_free_pages = buddy_nr_free_pages,
    .check = buddy_check,
};


